
node_id		The internal ID of the node

downstream_id	The internal ID of the node immediately downstream if the node

		[A "T" indicates its a terminal node, i.e. connects to existing pipeline]

Fac_ID		The biogas facility ID, if the node originates from it ("-1" indicates its a connector)

Waste		Waste originating at the node (if a biogas source)

Biogas		Biogas potential at the node (if a biogas source)

Type		"Source" = node occurs at a biogas source
		"Route" = node is a junciton along the route form sources to exiting pipeline
		"Output"= node occurs where the route meets an existing pipeline

Connection	"Transmission" = output node connects to an existing transmission pipeline
		"Distribution" = output node connects to an existing distribution pipeline
		"NA"/None = node is not an output node

Network		[NEED VERIFICATION]ID of the network to which the node belongs. 
		(Each network has its one connection to existing pipeline)

AccumWaste	Accumulated upstream Waste at the node

latitude/longitude Coordinates of the node
