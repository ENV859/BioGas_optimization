
node_id		The internal ID of the node
downstream_id	The internal ID of the node immediately downstream if the node
		[A "T" indicates its a terminal node, i.e. connects to existing pipeline]
Fac_ID		The biogas facility ID, if the node originates from it ("-1" indicates its a connector)
Waste		Waste originating at the node (if a biogas source)
Biogas		Biogas potential at the node (if a biogas source)
AccumWaste	Accumulated upstream Waste at the node
latitude/longitude Coordinates of the node
